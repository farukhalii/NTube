package com.example.data

import com.example.model.QualityOption
import com.example.model.ShortItem
import com.example.model.VideoItem
import kotlin.random.Random

object SampleData {

    val qualityOptions = listOf(
        QualityOption("1080p Full HD", "1920x1080", "52.4 MB", 52400000L),
        QualityOption("720p HD", "1280x720", "28.1 MB", 28100000L),
        QualityOption("480p SD", "854x480", "15.8 MB", 15800000L),
        QualityOption("360p Fast", "640x360", "8.6 MB", 8600000L),
        QualityOption("MP3 Audio", "320 kbps", "4.9 MB", 4900000L, isAudioOnly = true)
    )

    fun getInitialVideos(): List<VideoItem> {
        return listOf(
            VideoItem(
                id = "vid_001",
                title = "Trending songs that everyone listens and will make you dance like crazy x timestamps",
                channelName = "♡The._wonderland♡",
                channelAvatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80",
                channelAvatarColor = 0xFF9C27B0,
                views = "10M views",
                uploadTime = "1 year ago",
                duration = "11:27",
                thumbnailUrl = "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800&auto=format&fit=crop&q=80",
                centerPlayTitle = "Peligrosa",
                videoUrl = "https://www.youtube.com/watch?v=sample1"
            ),
            VideoItem(
                id = "vid_002",
                title = "MATUSHKA ULTRAFUNK (AUDIO EDIT)",
                channelName = "sukuna edits",
                channelAvatarUrl = "https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=150&auto=format&fit=crop&q=80",
                channelAvatarColor = 0xFF2196F3,
                views = "43M views",
                uploadTime = "1 year ago",
                duration = "0:52",
                thumbnailUrl = "https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?w=800&auto=format&fit=crop&q=80",
                centerPlayTitle = "MATUSHKA ULTRAFUNK [ AUDIO EDIT ]",
                videoUrl = "https://www.youtube.com/watch?v=sample2"
            ),
            VideoItem(
                id = "vid_003",
                title = "Heart Touching Quran Tilawat - Beautiful Recitation in Madinah Munawwarah",
                channelName = "Peaceful Soul",
                channelAvatarUrl = "https://images.unsplash.com/photo-1542838132-92c53300491e?w=150&auto=format&fit=crop&q=80",
                channelAvatarColor = 0xFF4CAF50,
                views = "18M views",
                uploadTime = "7 months ago",
                duration = "15:40",
                thumbnailUrl = "https://images.unsplash.com/photo-1584551246679-0daf3d275d0f?w=800&auto=format&fit=crop&q=80",
                centerPlayTitle = "Al-Madinah Peaceful Echo",
                videoUrl = "https://www.youtube.com/watch?v=sample3"
            ),
            VideoItem(
                id = "vid_004",
                title = "Phonk Drift Tokyo Night - Ultra Bass Boosted 2026",
                channelName = "Speed Demon",
                channelAvatarUrl = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80",
                channelAvatarColor = 0xFFE91E63,
                views = "27M views",
                uploadTime = "4 months ago",
                duration = "3:22",
                thumbnailUrl = "https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800&auto=format&fit=crop&q=80",
                centerPlayTitle = "TOKYO MIDNIGHT DRIFT",
                videoUrl = "https://www.youtube.com/watch?v=sample4"
            ),
            VideoItem(
                id = "vid_005",
                title = "Deep Focus Lofi Hip Hop Mix - Relaxing Beats to Study / Work to",
                channelName = "Lofi Girl Vibes",
                channelAvatarUrl = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80",
                channelAvatarColor = 0xFFFF9800,
                views = "89M views",
                uploadTime = "2 years ago",
                duration = "45:10",
                thumbnailUrl = "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800&auto=format&fit=crop&q=80",
                centerPlayTitle = "Midnight Coffee Beats",
                videoUrl = "https://www.youtube.com/watch?v=sample5"
            ),
            VideoItem(
                id = "vid_006",
                title = "Top 10 Insane Unbelievable Tech Inventions in 2026",
                channelName = "Future Tech Lab",
                channelAvatarUrl = "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80",
                channelAvatarColor = 0xFF00BCD4,
                views = "5.2M views",
                uploadTime = "3 weeks ago",
                duration = "14:18",
                thumbnailUrl = "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800&auto=format&fit=crop&q=80",
                centerPlayTitle = "Next-Gen Tech Horizon",
                videoUrl = "https://www.youtube.com/watch?v=sample6"
            )
        )
    }

    private val titles = listOf(
        "Nightcore Gaming Playlist - Best Bass Hits",
        "Cyberpunk 2077 Ultra Raytracing 4K 120FPS Gameplay",
        "Slowed + Reverb Sad Boy Hours Aesthetic Mix",
        "Brazilian Funk Mix 2026 - TikTok Trending Viral",
        "Nature 4K Wildlife Documentary - Amazon Rainforest",
        "GigaChad Theme Song [Ultra Slowed & Bass Boosted]",
        "Anime Epic Battle Scenes 4K 60FPS",
        "Unboxing the Most Powerful Portable Gaming Console",
        "Deep House Chillout Sunset Ibiza Live Session",
        "100 Days Hardcore Survival in Mysterious Open World"
    )

    private val channels = listOf(
        "NeonVibes" to 0xFFE91E63,
        "GameMaster X" to 0xFF3F51B5,
        "Aesthetic Echo" to 0xFF9C27B0,
        "Sonic Beats" to 0xFFFF5722,
        "Earth Visuals" to 0xFF4CAF50,
        "Sigma Sounds" to 0xFF607D8B,
        "Anime Nexus" to 0xFF00BCD4,
        "Tech Pulse" to 0xFFFFC107,
        "Club Ibiza" to 0xFFE040FB,
        "Survivalist" to 0xFF795548
    )

    private val thumbnailImages = listOf(
        "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=800&auto=format&fit=crop&q=80",
        "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800&auto=format&fit=crop&q=80",
        "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800&auto=format&fit=crop&q=80",
        "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=800&auto=format&fit=crop&q=80",
        "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800&auto=format&fit=crop&q=80",
        "https://images.unsplash.com/photo-1506157786151-b8491531f063?w=800&auto=format&fit=crop&q=80",
        "https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?w=800&auto=format&fit=crop&q=80",
        "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=800&auto=format&fit=crop&q=80"
    )

    fun generateMoreVideos(startIndex: Int, count: Int = 10): List<VideoItem> {
        return (0 until count).map { i ->
            val idx = startIndex + i
            val randomTitle = titles[Random.nextInt(titles.size)]
            val (channelName, color) = channels[Random.nextInt(channels.size)]
            val viewCount = (Random.nextInt(1, 95)).toString() + listOf("K", "M").random() + " views"
            val time = listOf("2 hours ago", "3 days ago", "2 weeks ago", "4 months ago", "1 year ago").random()
            val min = Random.nextInt(0, 15)
            val sec = String.format("%02d", Random.nextInt(5, 59))
            val duration = if (min == 0) "0:$sec" else "$min:$sec"
            val thumb = thumbnailImages[Random.nextInt(thumbnailImages.size)]

            VideoItem(
                id = "gen_vid_$idx",
                title = "$randomTitle #$idx",
                channelName = channelName,
                channelAvatarUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80",
                channelAvatarColor = color,
                views = viewCount,
                uploadTime = time,
                duration = duration,
                thumbnailUrl = thumb,
                centerPlayTitle = "▶ ${randomTitle.take(24)}",
                videoUrl = "https://www.youtube.com/watch?v=gen_$idx"
            )
        }
    }

    fun getInitialShorts(): List<ShortItem> {
        return listOf(
            ShortItem(
                id = "short_001",
                title = "Wait for the bass drop! 🤯 Insane drift in Tokyo #shorts #drift #phonk",
                channelName = "TokyoDriftOfficial",
                channelAvatarUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80",
                likesCount = "1.8M",
                commentsCount = "14.2K",
                videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
                audioTitle = "Original Audio - Phonk Drift Brazil",
                gradientColors = listOf(0xFF8A2387, 0xFFE94057, 0xFFF27121)
            ),
            ShortItem(
                id = "short_002",
                title = "Cat discovers mirror for the first time 😂 you won't believe reaction! #funny #cute",
                channelName = "MeowWorld",
                channelAvatarUrl = "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150&auto=format&fit=crop&q=80",
                likesCount = "3.4M",
                commentsCount = "29.8K",
                videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
                audioTitle = "Funny Cat Theme - Comedy Sound",
                gradientColors = listOf(0xFF0F2027, 0xFF203A43, 0xFF2C5364)
            ),
            ShortItem(
                id = "short_003",
                title = "Superhuman Calisthenics Routine in 30 Seconds 💪🔥 #gym #motivation",
                channelName = "IronMindset",
                channelAvatarUrl = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80",
                likesCount = "920K",
                commentsCount = "8.4K",
                videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
                audioTitle = "GigaChad Phonk Anthem",
                gradientColors = listOf(0xFF2C3E50, 0xFFFD746C, 0xFFFF9068)
            ),
            ShortItem(
                id = "short_004",
                title = "The most delicious 5-minute dessert you will ever make 🍫🤤 #food #recipe",
                channelName = "QuickChef",
                channelAvatarUrl = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80",
                likesCount = "2.1M",
                commentsCount = "18.6K",
                videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyBlazes.mp4",
                audioTitle = "Lofi Cooking Aesthetic Beat",
                gradientColors = listOf(0xFF141E30, 0xFF243B55, 0xFF4B79A1)
            )
        )
    }

    private val shortsTitles = listOf(
        "Top 3 mind-blowing facts you didn't know 🧠 #facts #shorts",
        "Insane basketball trick shot on the first try 🏀🔥 #sports",
        "How animations are made in studio 🎨✨ #art #creative",
        "Unbelievable guitar solo speed test 🎸⚡ #music #solo",
        "Cutting kinetic sand ASMR satisfying sound 🎧 #asmr #satisfying",
        "Secret smartphone tips you must turn on right now 📱 #tech",
        "Parkour roof jump POV - Don't look down! 🏃‍♂️💨 #adrenaline",
        "Drawing realistic 3D optical illusion on paper ✏️ #drawing"
    )

    fun generateMoreShorts(startIndex: Int, count: Int = 8): List<ShortItem> {
        val gradients = listOf(
            listOf(0xFF8A2387, 0xFFE94057, 0xFFF27121),
            listOf(0xFF12c2e9, 0xFFc471ed, 0xFFf64f59),
            listOf(0xFF0F2027, 0xFF203A43, 0xFF2C5364),
            listOf(0xFF3A1C71, 0xFFD76D77, 0xFFFFAF7B),
            listOf(0xFF134E5E, 0xFF71B280),
            listOf(0xFF654ea3, 0xFFeaafc8)
        )

        return (0 until count).map { i ->
            val idx = startIndex + i
            val randomTitle = shortsTitles[Random.nextInt(shortsTitles.size)]
            val (channel, _) = channels[Random.nextInt(channels.size)]
            val likes = "${Random.nextInt(100, 999)}K"
            val comments = "${Random.nextInt(1, 45)}.${Random.nextInt(1, 9)}K"

            ShortItem(
                id = "gen_short_$idx",
                title = "$randomTitle ($idx)",
                channelName = channel,
                channelAvatarUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80",
                likesCount = likes,
                commentsCount = comments,
                videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
                audioTitle = "Viral Audio Trending • $channel",
                gradientColors = gradients[Random.nextInt(gradients.size)]
            )
        }
    }
}
