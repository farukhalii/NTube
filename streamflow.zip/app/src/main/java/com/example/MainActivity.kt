package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.DownloadStatus
import com.example.ui.components.DownloadDialog
import com.example.ui.components.TopHeaderBar
import com.example.ui.components.VideoPlayerDialog
import com.example.ui.screens.DownloadScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ShortsScreen
import com.example.ui.screens.YouTubeWebViewScreen
import com.example.ui.screens.YouScreen
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NTubeRed
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                NTubeApp()
            }
        }
    }
}

@Composable
fun NTubeApp(viewModel: MainViewModel = viewModel()) {
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val isWebVisible by viewModel.isWebVisible.collectAsStateWithLifecycle()
    val webCurrentUrl by viewModel.webCurrentUrl.collectAsStateWithLifecycle()

    val videos by viewModel.videos.collectAsStateWithLifecycle()
    val shorts by viewModel.shorts.collectAsStateWithLifecycle()
    val downloads by viewModel.downloads.collectAsStateWithLifecycle()

    val selectedVideoForDownload by viewModel.selectedVideoForDownload.collectAsStateWithLifecycle()
    val selectedVideoForPlaying by viewModel.selectedVideoForPlaying.collectAsStateWithLifecycle()
    val unreadNotifications by viewModel.unreadNotifications.collectAsStateWithLifecycle()

    var showNotificationDialog by remember { mutableStateOf(false) }

    // Listen for download toast notifications
    LaunchedEffect(Unit) {
        viewModel.toastEvent.collect { message ->
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
            snackbarHostState.showSnackbar(message)
        }
    }

    // Handle back button when in webview or dialogs
    BackHandler(enabled = isWebVisible) {
        viewModel.closeWeb()
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = DarkBackground,
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(DarkBackground)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Top Header Bar: Logo, Bell, Search, and 4 Pill tabs (Home, Shorts, Download, You)
                TopHeaderBar(
                    currentTab = currentTab,
                    onTabSelected = { tab -> viewModel.setTab(tab) },
                    searchQuery = searchQuery,
                    onSearchQueryChange = { query -> viewModel.onSearchQueryChange(query) },
                    onSearchSubmitted = { query -> viewModel.triggerSearchOrNavigate(query) },
                    onOpenYouTubeWeb = { viewModel.openWebUrl("https://m.youtube.com") },
                    notificationCount = unreadNotifications,
                    downloadsCount = downloads.count { it.status == DownloadStatus.DOWNLOADING },
                    onNotificationClick = {
                        showNotificationDialog = true
                        viewModel.clearNotifications()
                    }
                )

                // Main Tab Content
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    when (currentTab) {
                        AppTab.HOME -> {
                            HomeScreen(
                                videos = videos,
                                onVideoClick = { video -> viewModel.openDownloadDialog(video) },
                                onDownloadClick = { video -> viewModel.openDownloadDialog(video) },
                                onLoadMore = { viewModel.loadMoreVideos() }
                            )
                        }

                        AppTab.SHORTS -> {
                            ShortsScreen(
                                shorts = shorts,
                                onDownloadShort = { video -> viewModel.openDownloadDialog(video) },
                                onLoadMore = { viewModel.loadMoreShorts() }
                            )
                        }

                        AppTab.DOWNLOAD -> {
                            DownloadScreen(
                                downloads = downloads,
                                onPlayDownload = { video -> viewModel.openPlayer(video) },
                                onPauseDownload = { id -> viewModel.pauseDownload(id) },
                                onResumeDownload = { id -> viewModel.resumeDownload(id) },
                                onDeleteDownload = { id -> viewModel.deleteDownload(id) },
                                onGoToHome = { viewModel.setTab(AppTab.HOME) }
                            )
                        }

                        AppTab.YOU -> {
                            YouScreen(
                                downloadsCount = downloads.count { it.status == DownloadStatus.COMPLETED },
                                onOpenDownloads = { viewModel.setTab(AppTab.DOWNLOAD) },
                                onOpenYouTubeWeb = { viewModel.openWebUrl("https://m.youtube.com") }
                            )
                        }
                    }
                }
            }

            // YouTube WebView Fullscreen Overlay if opened
            if (isWebVisible) {
                YouTubeWebViewScreen(
                    initialUrl = webCurrentUrl,
                    showCloseButton = true,
                    onClose = { viewModel.closeWeb() },
                    onDownloadDetectedVideo = { video -> viewModel.openDownloadDialog(video) }
                )
            }

            // Download Dialog Modal with resolution choices
            selectedVideoForDownload?.let { video ->
                DownloadDialog(
                    video = video,
                    onDismiss = { viewModel.closeDownloadDialog() },
                    onConfirmDownload = { quality ->
                        viewModel.startDownload(video, quality)
                    },
                    onPlayOnline = {
                        viewModel.closeDownloadDialog()
                        viewModel.openPlayer(video)
                    }
                )
            }

            // In-app Video Player Dialog
            selectedVideoForPlaying?.let { video ->
                VideoPlayerDialog(
                    video = video,
                    onDismiss = { viewModel.closePlayer() },
                    onDownloadClick = {
                        viewModel.closePlayer()
                        viewModel.openDownloadDialog(video)
                    }
                )
            }

            // Notifications Dialog
            if (showNotificationDialog) {
                AlertDialog(
                    onDismissRequest = { showNotificationDialog = false },
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Notifications, contentDescription = null, tint = NTubeRed)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("NTube Notifications", color = TextPrimary, fontWeight = FontWeight.Bold)
                        }
                    },
                    text = {
                        Column {
                            Text(
                                text = "🔔 Welcome to NTube!",
                                color = TextPrimary,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "Infinite videos and Shorts are ready. Tap any video or browse YouTube Web to download in HD.",
                                color = TextSecondary,
                                fontSize = 12.5.sp,
                                modifier = Modifier.padding(top = 4.dp, bottom = 10.dp)
                            )
                            Text(
                                text = "⚡ High-Speed Downloader",
                                color = TextPrimary,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "Downloads are saved directly in your Download tab for instant offline playback.",
                                color = TextSecondary,
                                fontSize = 12.5.sp,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = { showNotificationDialog = false }) {
                            Text("OK", color = NTubeRed, fontWeight = FontWeight.Bold)
                        }
                    },
                    containerColor = DarkSurface,
                    shape = RoundedCornerShape(16.dp)
                )
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "Hello $name!", modifier = modifier)
}

