package com.example

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.SampleData
import com.example.model.DownloadItem
import com.example.model.DownloadStatus
import com.example.model.QualityOption
import com.example.model.ShortItem
import com.example.model.VideoItem
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

enum class AppTab {
    HOME,
    SHORTS,
    DOWNLOAD,
    YOU
}

class MainViewModel : ViewModel() {

    private val _currentTab = MutableStateFlow(AppTab.HOME)
    val currentTab: StateFlow<AppTab> = _currentTab.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _isWebVisible = MutableStateFlow(false)
    val isWebVisible: StateFlow<Boolean> = _isWebVisible.asStateFlow()

    private val _webCurrentUrl = MutableStateFlow("https://m.youtube.com")
    val webCurrentUrl: StateFlow<String> = _webCurrentUrl.asStateFlow()

    private val _videos = MutableStateFlow<List<VideoItem>>(SampleData.getInitialVideos())
    val videos: StateFlow<List<VideoItem>> = _videos.asStateFlow()

    private val _shorts = MutableStateFlow<List<ShortItem>>(SampleData.getInitialShorts())
    val shorts: StateFlow<List<ShortItem>> = _shorts.asStateFlow()

    private val _downloads = MutableStateFlow<List<DownloadItem>>(emptyList())
    val downloads: StateFlow<List<DownloadItem>> = _downloads.asStateFlow()

    private val _selectedVideoForDownload = MutableStateFlow<VideoItem?>(null)
    val selectedVideoForDownload: StateFlow<VideoItem?> = _selectedVideoForDownload.asStateFlow()

    private val _selectedVideoForPlaying = MutableStateFlow<VideoItem?>(null)
    val selectedVideoForPlaying: StateFlow<VideoItem?> = _selectedVideoForPlaying.asStateFlow()

    private val _toastEvent = MutableSharedFlow<String>()
    val toastEvent: SharedFlow<String> = _toastEvent.asSharedFlow()

    private val _unreadNotifications = MutableStateFlow(2)
    val unreadNotifications: StateFlow<Int> = _unreadNotifications.asStateFlow()

    private val downloadJobs = mutableMapOf<String, Job>()

    fun setTab(tab: AppTab) {
        _currentTab.value = tab
    }

    fun onSearchQueryChange(query: String) {
        _searchQuery.value = query
    }

    fun triggerSearchOrNavigate(query: String) {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) return

        val targetUrl = if (trimmed.startsWith("http://") || trimmed.startsWith("https://") || trimmed.contains("youtube.com") || trimmed.contains("youtu.be")) {
            if (!trimmed.startsWith("http")) "https://$trimmed" else trimmed
        } else {
            "https://m.youtube.com/results?search_query=${android.net.Uri.encode(trimmed)}"
        }

        _webCurrentUrl.value = targetUrl
        _isWebVisible.value = true
    }

    fun openWebUrl(url: String = "https://m.youtube.com") {
        _webCurrentUrl.value = url
        _isWebVisible.value = true
    }

    fun closeWeb() {
        _isWebVisible.value = false
    }

    fun openDownloadDialog(video: VideoItem) {
        _selectedVideoForDownload.value = video
    }

    fun closeDownloadDialog() {
        _selectedVideoForDownload.value = null
    }

    fun openPlayer(video: VideoItem) {
        _selectedVideoForPlaying.value = video
    }

    fun closePlayer() {
        _selectedVideoForPlaying.value = null
    }

    fun clearNotifications() {
        _unreadNotifications.value = 0
    }

    // Infinite video generator when user scrolls near end
    fun loadMoreVideos() {
        viewModelScope.launch {
            val currentList = _videos.value
            val newItems = SampleData.generateMoreVideos(startIndex = currentList.size, count = 8)
            _videos.value = currentList + newItems
        }
    }

    // Infinite shorts generator when user scrolls near end
    fun loadMoreShorts() {
        viewModelScope.launch {
            val currentList = _shorts.value
            val newItems = SampleData.generateMoreShorts(startIndex = currentList.size, count = 6)
            _shorts.value = currentList + newItems
        }
    }

    fun startDownload(video: VideoItem, quality: QualityOption) {
        closeDownloadDialog()

        val downloadId = UUID.randomUUID().toString()
        val dateFormat = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
        val dateString = dateFormat.format(Date())

        val newDownload = DownloadItem(
            id = downloadId,
            videoId = video.id,
            title = video.title,
            channelName = video.channelName,
            thumbnailUrl = video.thumbnailUrl,
            quality = quality.label,
            isAudio = quality.isAudioOnly,
            totalSizeBytes = quality.sizeBytes,
            downloadedBytes = 0L,
            progress = 0f,
            speed = "4.5 MB/s",
            status = DownloadStatus.DOWNLOADING,
            dateAdded = dateString,
            localUri = "file:///storage/emulated/0/NTube/${video.id}_${quality.resolution}.mp4"
        )

        _downloads.update { listOf(newDownload) + it }
        emitToast("Starting download: ${video.title.take(30)}... (${quality.label})")

        // Start background download progression
        runDownloadSimulation(downloadId, quality.sizeBytes)
    }

    private fun runDownloadSimulation(downloadId: String, totalSize: Long) {
        val job = viewModelScope.launch {
            var currentBytes = 0L
            val stepSize = (totalSize / 40).coerceAtLeast(200_000L)

            while (currentBytes < totalSize) {
                delay(250)

                val download = _downloads.value.find { it.id == downloadId }
                if (download == null || download.status == DownloadStatus.PAUSED || download.status == DownloadStatus.FAILED) {
                    break
                }

                currentBytes = (currentBytes + stepSize + (0..150000).random()).coerceAtMost(totalSize)
                val progress = (currentBytes.toFloat() / totalSize.toFloat()).coerceIn(0f, 1f)
                val speedVal = String.format(Locale.US, "%.1f MB/s", 3.5 + (0..20).random() * 0.1)

                _downloads.update { list ->
                    list.map { item ->
                        if (item.id == downloadId) {
                            item.copy(
                                downloadedBytes = currentBytes,
                                progress = progress,
                                speed = speedVal,
                                status = if (progress >= 1f) DownloadStatus.COMPLETED else DownloadStatus.DOWNLOADING
                            )
                        } else item
                    }
                }
            }

            // Completed!
            _downloads.update { list ->
                list.map { item ->
                    if (item.id == downloadId) {
                        item.copy(
                            downloadedBytes = totalSize,
                            progress = 1f,
                            speed = "Completed",
                            status = DownloadStatus.COMPLETED
                        )
                    } else item
                }
            }
            emitToast("Download completed: Ready to play offline!")
        }
        downloadJobs[downloadId] = job
    }

    fun pauseDownload(id: String) {
        downloadJobs[id]?.cancel()
        _downloads.update { list ->
            list.map { if (it.id == id) it.copy(status = DownloadStatus.PAUSED, speed = "Paused") else it }
        }
    }

    fun resumeDownload(id: String) {
        val item = _downloads.value.find { it.id == id } ?: return
        _downloads.update { list ->
            list.map { if (it.id == id) it.copy(status = DownloadStatus.DOWNLOADING, speed = "Resuming...") else it }
        }
        runDownloadSimulation(id, item.totalSizeBytes)
    }

    fun deleteDownload(id: String) {
        downloadJobs[id]?.cancel()
        downloadJobs.remove(id)
        _downloads.update { list -> list.filterNot { it.id == id } }
        emitToast("Video deleted from downloads")
    }

    private fun emitToast(msg: String) {
        viewModelScope.launch {
            _toastEvent.emit(msg)
        }
    }
}
