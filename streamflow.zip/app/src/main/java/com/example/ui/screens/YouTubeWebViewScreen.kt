package com.example.ui.screens

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.model.VideoItem
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.NTubeRed
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun YouTubeWebViewScreen(
    initialUrl: String = "https://m.youtube.com",
    showCloseButton: Boolean = true,
    onClose: () -> Unit = {},
    onDownloadDetectedVideo: (VideoItem) -> Unit,
    modifier: Modifier = Modifier
) {
    var webViewInstance by remember { mutableStateOf<WebView?>(null) }
    var currentUrl by remember { mutableStateOf(initialUrl) }
    var pageTitle by remember { mutableStateOf("YouTube") }
    var loadingProgress by remember { mutableFloatStateOf(0f) }
    var isLoading by remember { mutableStateOf(true) }

    // Detected video info
    val isShort = currentUrl.contains("/shorts/")
    val isVideoPage = currentUrl.contains("watch?v=") || isShort

    // Extract YouTube 11-char Video ID if present
    val extractedVideoId = remember(currentUrl) {
        val regex = Regex("(?:watch\\?v=|shorts/|youtu\\.be/)([a-zA-Z0-9_-]{11})")
        regex.find(currentUrl)?.groupValues?.getOrNull(1)
    }

    // Intercept back navigation to go back in WebView history if possible
    BackHandler {
        if (webViewInstance?.canGoBack() == true) {
            webViewInstance?.goBack()
        } else if (showCloseButton) {
            onClose()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Web Navigation Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSurfaceElevated)
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        if (webViewInstance?.canGoBack() == true) {
                            webViewInstance?.goBack()
                        } else if (showCloseButton) {
                            onClose()
                        }
                    },
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = TextPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                IconButton(
                    onClick = { webViewInstance?.goForward() },
                    enabled = webViewInstance?.canGoForward() == true,
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "Forward",
                        tint = if (webViewInstance?.canGoForward() == true) TextPrimary else Color.Gray,
                        modifier = Modifier.size(20.dp)
                    )
                }

                IconButton(
                    onClick = { webViewInstance?.reload() },
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Reload",
                        tint = TextPrimary,
                        modifier = Modifier.size(19.dp)
                    )
                }

                // URL & Title pill
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 4.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(DarkSurface)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = pageTitle.ifEmpty { "YouTube" },
                        color = TextPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = currentUrl,
                        color = TextSecondary,
                        fontSize = 9.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                if (showCloseButton) {
                    IconButton(
                        onClick = onClose,
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close Web",
                            tint = TextPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            // Quick Category Shortcuts (All Videos, Shorts, Trending)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSurfaceElevated)
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                WebCategoryChip(
                    label = "Home (All Videos)",
                    icon = Icons.Default.Home,
                    isSelected = currentUrl == "https://m.youtube.com" || currentUrl == "https://m.youtube.com/",
                    onClick = { webViewInstance?.loadUrl("https://m.youtube.com") }
                )
                WebCategoryChip(
                    label = "YouTube Shorts",
                    icon = Icons.Default.PlayArrow,
                    isSelected = currentUrl.contains("/shorts"),
                    onClick = { webViewInstance?.loadUrl("https://m.youtube.com/shorts") }
                )
                WebCategoryChip(
                    label = "Trending",
                    icon = Icons.Default.Whatshot,
                    isSelected = currentUrl.contains("trending"),
                    onClick = { webViewInstance?.loadUrl("https://m.youtube.com/feed/trending") }
                )
                WebCategoryChip(
                    label = "Music",
                    isSelected = currentUrl.contains("music"),
                    onClick = { webViewInstance?.loadUrl("https://m.youtube.com/channel/UC-9-kyTW8ZkZNDHQJ6FgpwQ") }
                )
                WebCategoryChip(
                    label = "Gaming",
                    isSelected = currentUrl.contains("gaming"),
                    onClick = { webViewInstance?.loadUrl("https://m.youtube.com/gaming") }
                )
            }

            // Progress Bar
            if (isLoading) {
                LinearProgressIndicator(
                    progress = { loadingProgress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(2.dp),
                    color = NTubeRed,
                    trackColor = Color.Transparent
                )
            }

            // Android WebView
            AndroidView(
                factory = { context ->
                    WebView(context).apply {
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                        settings.apply {
                            javaScriptEnabled = true
                            domStorageEnabled = true
                            databaseEnabled = true
                            mediaPlaybackRequiresUserGesture = false
                            loadWithOverviewMode = true
                            useWideViewPort = true
                            cacheMode = WebSettings.LOAD_DEFAULT
                            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                            userAgentString = "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                        }

                        webViewClient = object : WebViewClient() {
                            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                                val url = request?.url?.toString() ?: return false
                                // Stay inside WebView for youtube and google domains
                                if (url.contains("youtube.com") || url.contains("youtu.be") || url.contains("google.com")) {
                                    return false
                                }
                                return false
                            }

                            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                                isLoading = true
                                url?.let { currentUrl = it }
                            }

                            override fun onPageFinished(view: WebView?, url: String?) {
                                isLoading = false
                                url?.let { currentUrl = it }
                                view?.title?.let { if (it.isNotEmpty()) pageTitle = it }
                            }

                            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                                super.doUpdateVisitedHistory(view, url, isReload)
                                url?.let { currentUrl = it }
                                view?.title?.let { if (it.isNotEmpty()) pageTitle = it }
                            }

                            override fun onRenderProcessGone(view: WebView?, detail: android.webkit.RenderProcessGoneDetail?): Boolean {
                                return true
                            }
                        }

                        webChromeClient = object : WebChromeClient() {
                            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                loadingProgress = newProgress / 100f
                                if (newProgress >= 100) {
                                    isLoading = false
                                }
                            }

                            override fun onReceivedTitle(view: WebView?, title: String?) {
                                title?.let { if (it.isNotEmpty()) pageTitle = it }
                            }
                        }

                        loadUrl(initialUrl)
                        webViewInstance = this
                    }
                },
                update = { webView ->
                    // Only reload if initialUrl explicitly changed and webView is not already there
                    if (initialUrl.isNotEmpty() && !webView.url.orEmpty().startsWith(initialUrl.substringBefore("?")) && webView.url.isNullOrEmpty()) {
                        webView.loadUrl(initialUrl)
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        }

        // Floating Download Button for active YouTube page or short
        ExtendedFloatingActionButton(
            onClick = {
                val cleanTitle = if (pageTitle.contains("- YouTube")) {
                    pageTitle.substringBefore("- YouTube").trim()
                } else pageTitle.ifEmpty { if (isShort) "YouTube Short" else "YouTube Video" }

                val videoId = extractedVideoId ?: "yt_${System.currentTimeMillis()}"
                val thumbUrl = if (extractedVideoId != null) {
                    "https://img.youtube.com/vi/$extractedVideoId/hqdefault.jpg"
                } else {
                    "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800&auto=format&fit=crop&q=80"
                }

                val detectedVideo = VideoItem(
                    id = videoId,
                    title = cleanTitle,
                    channelName = if (isShort) "YouTube Shorts" else "YouTube Web",
                    channelAvatarUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80",
                    views = if (isShort) "Shorts Feed" else "Real YouTube",
                    uploadTime = "Now",
                    duration = if (isShort) "0:45" else "Full HD",
                    thumbnailUrl = thumbUrl,
                    videoUrl = currentUrl
                )
                onDownloadDetectedVideo(detectedVideo)
            },
            containerColor = NTubeRed,
            contentColor = Color.White,
            shape = RoundedCornerShape(26.dp),
            elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 8.dp),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(18.dp)
                .shadow(12.dp, RoundedCornerShape(26.dp)),
            icon = {
                Icon(
                    imageVector = Icons.Default.Download,
                    contentDescription = null,
                    modifier = Modifier.size(24.dp)
                )
            },
            text = {
                Text(
                    text = if (isShort) "Download Short" else if (isVideoPage) "Download Video" else "Download This Page",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
        )
    }
}

@Composable
private fun WebCategoryChip(
    label: String,
    icon: ImageVector? = null,
    isSelected: Boolean = false,
    onClick: () -> Unit
) {
    val bg = if (isSelected) NTubeRed else DarkSurface
    val borderCol = if (isSelected) NTubeRed else Color(0xFF333333)

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(bg)
            .border(1.dp, borderCol, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        if (icon != null) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(13.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
        }
        Text(
            text = label,
            color = Color.White,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
        )
    }
}
